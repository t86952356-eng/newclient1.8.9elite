param([string]$OutputDirectory)
$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path -Parent $PSScriptRoot
if (-not $OutputDirectory) { $OutputDirectory = $taskRoot }
$OutputDirectory = [System.IO.Path]::GetFullPath($OutputDirectory)
Push-Location $taskRoot
try {
    & (Join-Path $PSScriptRoot 'build-native.ps1')
    $javaCompiler = (Get-Command javac -ErrorAction Stop).Source
    $javaRunner = (Get-Command java -ErrorAction Stop).Source
    $jarTool = (Get-Command jar -ErrorAction Stop).Source
    $asmPath = 'work/agent-classes;tools/asm-9.9.jar;tools/asm-tree-9.9.jar;tools/asm-analysis-9.9.jar'
    New-Item -ItemType Directory -Force -Path 'launcher/build','runtime/natives','runtime/game','runtime/logs',(Join-Path $OutputDirectory 'launcher') | Out-Null
    $sources = Get-ChildItem -LiteralPath 'launcher/src' -Recurse -Filter '*.java' | ForEach-Object { $_.FullName }
    & $javaCompiler --release 17 -cp ($asmPath + ';artifacts/client-restored.jar;artifacts/libraries.jar') -d 'launcher/build' @sources
    if ($LASTEXITCODE -ne 0) { throw 'Launcher compilation failed.' }
    & $javaRunner -Xmx2G -cp ('launcher/build;' + $asmPath + ';artifacts/libraries.jar') BuildOfflinePatch 'artifacts/client-restored.jar' (Join-Path $OutputDirectory 'launcher/offline-patches.jar') (Join-Path $OutputDirectory 'launcher/patches.txt')
    if ($LASTEXITCODE -ne 0) { throw 'Client patch build failed.' }
    Copy-Item -LiteralPath 'Inter_18pt-Regular.ttf' -Destination 'launcher/build/Inter.ttf'
    Copy-Item -LiteralPath 'launcher/resources/client-release.properties' -Destination 'launcher/build/client-release.properties'
    if (Test-Path -LiteralPath 'launcher/resources/cas-configs/catalog.json') { Copy-Item -LiteralPath 'launcher/resources/cas-configs' -Destination 'launcher/build' -Recurse -Force }
    if (Test-Path -LiteralPath 'launcher/build/PortableStub.exe') { Remove-Item -LiteralPath 'launcher/build/PortableStub.exe' }
    & $jarTool cfm (Join-Path $OutputDirectory 'RiseLocalLauncher.jar') 'launcher/launcher.mf' -C 'launcher/build' .
    if ($LASTEXITCODE -ne 0) { throw 'Launcher packaging failed.' }
    $nativeSource = Join-Path $env:APPDATA 'Rise/dependants/windows/1.8.9-natives'
    if (Test-Path -LiteralPath $nativeSource) {
        Get-ChildItem -LiteralPath $nativeSource -File | Copy-Item -Destination 'runtime/natives'
    }
    if (-not (Test-Path -LiteralPath 'runtime/natives/lwjgl64.dll')) { throw 'LWJGL native libraries were not found.' }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $clientArchive = [System.IO.Compression.ZipFile]::OpenRead((Join-Path $taskRoot 'artifacts/client-restored.jar'))
    try {
        foreach ($library in @('libcrypto-3-x64.dll','libssl-3-x64.dll','rise_native.dll')) {
            $entry = $clientArchive.GetEntry('native/' + $library)
            if (-not $entry) { throw "Missing client native resource: $library" }
            $inputStream = $entry.Open()
            $outputStream = [System.IO.File]::Create((Join-Path $taskRoot ('runtime/natives/' + $library)))
            try { $inputStream.CopyTo($outputStream) }
            finally { $inputStream.Dispose(); $outputStream.Dispose() }
        }
    }
    finally { $clientArchive.Dispose() }
    Write-Output 'Built RiseLocalLauncher.jar. Open Launch-Rise.cmd to start.'
}
finally { Pop-Location }
