package rise.local.config;

import java.awt.*;
import java.nio.file.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.*;
import javax.swing.table.*;
import rise.local.ui.LauncherTheme;
import rise.local.ui.Motion;
import rise.local.ui.MotionLabel;
import rise.local.ui.MotionPanel;

public final class OnlineConfigDialog extends JDialog {
    private volatile OnlineConfigRepository repository;
    private final Path cache;
    private final Path exports;
    private final DefaultTableModel model=new DefaultTableModel(new String[]{"Config","Server","Updated"},0){public boolean isCellEditable(int row,int column){return false;}};
    private final JTable table=new JTable(model);
    private final TableRowSorter<DefaultTableModel> sorter=new TableRowSorter<>(model);
    private final JLabel status=new MotionLabel("Loading configs...");
    private final JButton update=LauncherTheme.button("Update",false);
    private final JButton save=LauncherTheme.button("Download selected",true);
    private final MotionPanel results;
    private final Motion.Tween selection=new Motion.Tween(1,value->table.repaint());
    private final java.util.List<OnlineConfigRepository.Entry> rows=new ArrayList<>();

    public OnlineConfigDialog(JFrame parent,Path gameDirectory)throws Exception {
        super(parent,"Configs",false);exports=gameDirectory.resolve("Rise/configs");cache=gameDirectory.resolve("Rise/online-configs");
        setSize(740,490);setMinimumSize(new Dimension(640,400));setLocationRelativeTo(parent);
        JPanel content=new JPanel(new BorderLayout(12,16));content.setBorder(new EmptyBorder(20,22,18,22));MotionPanel.install(this,content);
        JPanel heading=new JPanel(new BorderLayout(12,8));heading.add(LauncherTheme.label("Search",13,LauncherTheme.MUTED),BorderLayout.WEST);
        JTextField search=new JTextField();LauncherTheme.field(search);search.setToolTipText("Search by config name or server");heading.add(search,BorderLayout.CENTER);content.add(heading,BorderLayout.NORTH);
        table.setRowSorter(sorter);table.setRowHeight(29);table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);table.getTableHeader().setReorderingAllowed(false);
        table.setDefaultRenderer(Object.class,new DefaultTableCellRenderer(){public Component getTableCellRendererComponent(JTable owner,Object value,boolean selected,boolean focus,int row,int column){Component component=super.getTableCellRendererComponent(owner,value,selected,false,row,column);component.setBackground(selected?LauncherTheme.mix(LauncherTheme.SURFACE,new Color(44,68,94),selection.value()):LauncherTheme.SURFACE);return component;}});
        table.getSelectionModel().addListSelectionListener(event->{if(!event.getValueIsAdjusting()){selection.snap(0);selection.to(1,140);}});
        results=new MotionPanel(LauncherTheme.scroll(table),0);content.add(results,BorderLayout.CENTER);
        search.getDocument().addDocumentListener(new DocumentListener(){public void insertUpdate(DocumentEvent event){filter();}public void removeUpdate(DocumentEvent event){filter();}public void changedUpdate(DocumentEvent event){filter();}private void filter(){String value=search.getText().trim();sorter.setRowFilter(value.isEmpty()?null:RowFilter.regexFilter("(?i)"+java.util.regex.Pattern.quote(value)));results.refresh();}});
        JPanel footer=new JPanel(new BorderLayout(8,10));JPanel buttons=new JPanel(new FlowLayout(FlowLayout.LEFT,8,0));buttons.add(update);
        save.addActionListener(event->download());buttons.add(save);save.setEnabled(false);update.setPreferredSize(new Dimension(94,40));
        JButton folder=LauncherTheme.button("Config folder",false);folder.addActionListener(event->{try{Files.createDirectories(exports);Desktop.getDesktop().open(exports.toFile());}catch(Exception error){status.setText(error.getMessage());}});buttons.add(folder);
        footer.add(buttons,BorderLayout.NORTH);footer.add(status,BorderLayout.SOUTH);content.add(footer,BorderLayout.SOUTH);
        update.addActionListener(event->refresh());refresh();
    }
    private void showCatalog() {
        if(repository==null)return;
        String selected=table.getSelectedRow()<0?null:rows.get(table.convertRowIndexToModel(table.getSelectedRow())).file();
        rows.clear();model.setRowCount(0);OnlineConfigRepository.Catalog catalog=repository.catalog();if(catalog==null)return;
        rows.addAll(catalog.entries());rows.sort(Comparator.comparing(OnlineConfigRepository.Entry::name,String.CASE_INSENSITIVE_ORDER));
        for(var row:rows)model.addRow(new Object[]{row.name(),row.ip(),row.updated()});
        if(selected!=null)for(int index=0;index<rows.size();index++)if(rows.get(index).file().equals(selected)){int visible=table.convertRowIndexToView(index);if(visible>=0)table.setRowSelectionInterval(visible,visible);}
        save.setEnabled(true);results.refresh();
        status.setText(rows.size()+" configs");status.setForeground(LauncherTheme.MUTED);
    }
    private void refresh() {
        update.setEnabled(false);LauncherTheme.busy(update,true);status.setText(repository==null?"Loading configs...":"Checking for updates...");
        new SwingWorker<Void,OnlineConfigRepository.Catalog>() {
            protected Void doInBackground()throws Exception{if(repository==null)repository=new OnlineConfigRepository(cache);if(repository.catalog()!=null)publish(repository.catalog());repository.refresh();repository.exportAll(exports);return null;}
            protected void process(java.util.List<OnlineConfigRepository.Catalog> snapshots){if(isDisplayable())showCatalog();}
            protected void done(){update.setEnabled(true);LauncherTheme.busy(update,false);if(!isDisplayable())return;try{get();showCatalog();}catch(Exception error){showCatalog();status.setText(repository!=null&&repository.catalog()!=null?"Using saved configs":"Unable to load configs");status.setToolTipText(error.getCause()==null?error.getMessage():error.getCause().getMessage());}}
        }.execute();
    }
    private void download() {
        int selected=table.getSelectedRow();if(selected<0){status.setText("Select a config first.");return;}
        OnlineConfigRepository.Entry item=rows.get(table.convertRowIndexToModel(selected));
        save.setEnabled(false);LauncherTheme.busy(save,true);status.setText("Saving "+item.name()+"...");
        new SwingWorker<Path,Void>(){protected Path doInBackground()throws Exception{return repository.export(item.name(),exports);}protected void done(){save.setEnabled(true);LauncherTheme.busy(save,false);if(!isDisplayable())return;try{status.setText("Saved "+get().getFileName());}catch(Exception error){status.setText("Download failed");status.setToolTipText(error.getMessage());}}}.execute();
    }
}
