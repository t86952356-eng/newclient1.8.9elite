package rise.local.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleConsumer;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

public final class Motion {
    private interface Animation { boolean tick(long now); }
    private static final List<Animation> active = new ArrayList<>();
    private static final Timer clock = new Timer(16, event -> tick());
    private static boolean enabled = !"false".equalsIgnoreCase(System.getProperty("rise.ui.motion"));
    static { clock.setCoalesce(true); }
    private Motion() { }

    private static void add(Animation animation) {
        if (!active.contains(animation)) active.add(animation);
        if (!clock.isRunning()) clock.start();
    }
    private static void remove(Animation animation) {
        active.remove(animation);
        if (active.isEmpty()) clock.stop();
    }
    private static void tick() {
        long now = System.nanoTime();
        for (Animation animation : List.copyOf(active)) if (active.contains(animation) && !animation.tick(now)) remove(animation);
        if (active.isEmpty()) clock.stop();
    }
    public static boolean enabled() { return enabled; }
    public static int activeCount() { return active.size(); }
    public static void setEnabled(boolean value) {
        enabled = value;
        if (!value) for (Animation animation : List.copyOf(active)) {
            if (animation instanceof Tween tween) tween.finish();
            else if (animation instanceof Pulse pulse) pulse.stop();
        }
    }
    public static double ease(double progress) {
        double remaining = 1 - Math.max(0, Math.min(1, progress));
        return 1 - remaining * remaining * remaining;
    }

    public static final class Tween implements Animation {
        private double start, target, value;
        private long started, duration;
        private final DoubleConsumer changed;
        private Runnable finished;
        public Tween(double initial, DoubleConsumer changed) { start = target = value = initial; this.changed = changed; }
        private double sample(long now) {
            if (duration == 0) return target;
            return start + (target - start) * ease((double) (now - started) / duration);
        }
        public double value() { return active.contains(this) ? sample(System.nanoTime()) : value; }
        public void to(double next, int milliseconds) { to(next, milliseconds, 0, null); }
        public void to(double next, int milliseconds, int delay, Runnable completed) {
            if (!SwingUtilities.isEventDispatchThread()) { SwingUtilities.invokeLater(() -> to(next, milliseconds, delay, completed)); return; }
            if (active.contains(this) && Math.abs(next - target) < .00001 && completed == null) return;
            long now = System.nanoTime();
            start = value = value(); target = next; started = now + delay * 1_000_000L;
            duration = Math.max(0, milliseconds) * 1_000_000L; finished = completed;
            if (!enabled || duration == 0 || Math.abs(start - target) < .00001) { finish(); return; }
            add(this); changed.accept(value);
        }
        public void snap(double next) {
            remove(this); start = target = value = next; duration = 0; finished = null; changed.accept(value);
        }
        public void finish() {
            remove(this); value = start = target; duration = 0; changed.accept(value);
            Runnable callback = finished; finished = null; if (callback != null) callback.run();
        }
        @Override public boolean tick(long now) {
            value = sample(now); changed.accept(value);
            if (now >= started + duration) { finish(); return false; }
            return true;
        }
    }

    public static final class Pulse implements Animation {
        private final Runnable changed;
        private boolean running;
        public Pulse(Runnable changed) { this.changed = changed; }
        public void start() { if (!running && enabled) { running = true; add(this); } }
        public void stop() { running = false; remove(this); }
        @Override public boolean tick(long now) { if (running) changed.run(); return running; }
    }
}
