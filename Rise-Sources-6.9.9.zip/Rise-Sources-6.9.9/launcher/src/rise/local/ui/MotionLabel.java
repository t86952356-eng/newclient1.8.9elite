package rise.local.ui;

import java.awt.*;
import java.util.Objects;
import javax.swing.JLabel;

public final class MotionLabel extends JLabel {
    private double amount = 1;
    private final Motion.Tween fade = new Motion.Tween(1, value -> { amount = value; repaint(); });
    public MotionLabel(String text) { super(text); }
    @Override public void setText(String text) {
        if (Objects.equals(text, getText())) return;
        super.setText(text);
        if (fade != null && isShowing()) { fade.snap(0); fade.to(1, 160); }
    }
    @Override protected void paintComponent(Graphics graphics) {
        Graphics2D g = (Graphics2D) graphics.create();
        float parent = g.getComposite() instanceof AlphaComposite composite ? composite.getAlpha() : 1;
        g.setComposite(AlphaComposite.SrcOver.derive(parent * (float) amount));
        g.translate(0, 3 * (1 - amount)); super.paintComponent(g); g.dispose();
    }
    @Override public void removeNotify() { fade.snap(1); super.removeNotify(); }
}
