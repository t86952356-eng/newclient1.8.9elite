package rise.local.ui;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.FontUIResource;
import javax.swing.plaf.basic.*;
import javax.swing.event.*;

public final class LauncherTheme {
    public static final Color BACKGROUND = new Color(16, 18, 20);
    public static final Color SURFACE = new Color(25, 28, 31);
    public static final Color LINE = new Color(44, 49, 54);
    public static final Color TEXT = new Color(235, 238, 240);
    public static final Color MUTED = new Color(143, 152, 160);
    public static final Color ACCENT = new Color(151, 193, 248);
    private LauncherTheme() { }

    public static void install() throws Exception {
        UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        Font inter;
        try (InputStream input = LauncherTheme.class.getResourceAsStream("/Inter.ttf")) {
            if (input == null) throw new IOException("Missing Inter font.");
            inter = Font.createFont(Font.TRUETYPE_FONT, input).deriveFont(13f);
        }
        for (Object key : new java.util.ArrayList<>(UIManager.getDefaults().keySet())) {
            if (UIManager.get(key) instanceof Font) UIManager.put(key, new FontUIResource(inter));
        }
        for (String key : new String[]{"Panel", "OptionPane", "Viewport", "ScrollPane"}) UIManager.put(key + ".background", BACKGROUND);
        for (String key : new String[]{"Label", "CheckBox", "RadioButton", "OptionPane", "MenuItem"}) UIManager.put(key + ".foreground", TEXT);
        for (String key : new String[]{"TextField", "TextArea", "Table", "List", "ComboBox"}) {
            UIManager.put(key + ".background", SURFACE); UIManager.put(key + ".foreground", TEXT);
            UIManager.put(key + ".selectionBackground", new Color(44, 68, 94)); UIManager.put(key + ".selectionForeground", TEXT);
        }
        UIManager.put("TextField.caretForeground", TEXT);
        UIManager.put("Table.gridColor", LINE);
        UIManager.put("TableHeader.background", SURFACE); UIManager.put("TableHeader.foreground", MUTED);
        UIManager.put("ScrollBar.width", 9);
        UIManager.put("ScrollBar.thumb", LINE); UIManager.put("ScrollBar.track", BACKGROUND);
        UIManager.put("ComboBox.buttonBackground", SURFACE);
        UIManager.put("CheckBox.background", BACKGROUND);
        UIManager.put("ToolTip.background", SURFACE); UIManager.put("ToolTip.foreground", TEXT);
    }

    public static JPanel panel(LayoutManager layout) { JPanel panel = new JPanel(layout); panel.setOpaque(false); return panel; }
    public static JLabel label(String text, int size, Color color) {
        JLabel label = new JLabel(text); label.setFont(label.getFont().deriveFont((float) size)); label.setForeground(color); return label;
    }
    public static void field(JTextField field) {
        field.setBackground(SURFACE); field.setForeground(TEXT); field.setCaretColor(TEXT);
        if (field.getClientProperty("rise.animatedField") == null) {
            Motion.Tween focus = new Motion.Tween(0, value -> field.repaint());
            Motion.Tween hover = new Motion.Tween(0, value -> field.repaint());
            Motion.Tween invalid = new Motion.Tween(0, value -> field.repaint());
            field.setBorder(new AbstractBorder() {
                @Override public Insets getBorderInsets(Component component) { return new Insets(12, 14, 12, 14); }
                @Override public Insets getBorderInsets(Component component, Insets insets) { insets.set(12, 14, 12, 14); return insets; }
                @Override public void paintBorder(Component component, Graphics graphics, int x, int y, int width, int height) {
                    Color line = mix(LINE, new Color(71, 81, 91), hover.value());
                    line = mix(line, ACCENT, focus.value() * .85);
                    graphics.setColor(mix(line, new Color(225, 121, 119), invalid.value()));
                    graphics.drawRect(x, y, width - 1, height - 1);
                }
            });
            field.addFocusListener(new FocusAdapter() {
                @Override public void focusGained(FocusEvent event) { focus.to(1, 150); }
                @Override public void focusLost(FocusEvent event) { focus.to(0, 170); }
            });
            field.addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent event) { hover.to(1, 130); }
                @Override public void mouseExited(MouseEvent event) { hover.to(0, 150); }
            });
            field.addPropertyChangeListener("rise.invalid", event -> invalid.to(Boolean.TRUE.equals(event.getNewValue()) ? 1 : 0, 150));
            field.putClientProperty("rise.animatedField", true);
        }
        field.setPreferredSize(new Dimension(300, 46));
    }
    public static JButton button(String text, boolean primary) { return new FlatButton(text, primary); }
    public static JButton windowButton(Icon icon, boolean close) {
        JButton button = new FlatButton("", false); button.setIcon(icon);
        button.putClientProperty("rise.chrome", true); button.putClientProperty("rise.danger", close); button.setBorder(new EmptyBorder(0, 0, 0, 0));
        return button;
    }
    public static void busy(JButton button, boolean value) { button.putClientProperty("rise.busy", value); }
    public static Color mix(Color from, Color to, double progress) {
        double t = Math.max(0, Math.min(1, progress));
        return new Color((int) Math.round(from.getRed() + (to.getRed() - from.getRed()) * t),
            (int) Math.round(from.getGreen() + (to.getGreen() - from.getGreen()) * t),
            (int) Math.round(from.getBlue() + (to.getBlue() - from.getBlue()) * t));
    }
    public static void toggle(JCheckBox box) {
        Motion.Tween selected = new Motion.Tween(box.isSelected() ? 1 : 0, value -> box.repaint());
        Motion.Tween hover = new Motion.Tween(0, value -> box.repaint());
        Icon icon = new Icon() {
            public int getIconWidth() { return 32; }
            public int getIconHeight() { return 19; }
            public void paintIcon(Component component, Graphics graphics, int x, int y) {
                double value = selected.value(); Graphics2D g = (Graphics2D) graphics.create();
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g.setColor(mix(mix(LINE, new Color(61, 70, 80), hover.value()), ACCENT, value));
                g.fillRoundRect(x, y, 32, 19, 19, 19);
                g.setColor(mix(MUTED, BACKGROUND, value));
                g.fillOval(x + (int) Math.round(3 + 13 * value), y + 3, 13, 13);
                if (box.hasFocus()) { g.setColor(mix(LINE, ACCENT, .7)); g.drawRoundRect(x - 2, y - 2, 36, 23, 22, 22); }
                g.dispose();
            }
        };
        box.setIcon(icon); box.setSelectedIcon(icon); box.setOpaque(false); box.setFocusPainted(false);
        box.setForeground(TEXT); box.setIconTextGap(9); box.setHorizontalTextPosition(SwingConstants.LEFT);
        box.addItemListener(event -> selected.to(box.isSelected() ? 1 : 0, 180));
        box.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent event) { hover.to(1, 120); }
            @Override public void mouseExited(MouseEvent event) { hover.to(0, 150); }
        });
        box.addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent event) { box.repaint(); }
            @Override public void focusLost(FocusEvent event) { box.repaint(); }
        });
    }
    public static void combo(JComboBox<?> box) {
        Motion.Tween opened = new Motion.Tween(0, value -> box.repaint());
        Motion.Tween focus = new Motion.Tween(0, value -> box.repaint());
        box.setBorder(new AbstractBorder() {
            @Override public Insets getBorderInsets(Component component) { return new Insets(1, 1, 1, 1); }
            @Override public void paintBorder(Component component, Graphics g, int x, int y, int width, int height) {
                g.setColor(mix(LINE, ACCENT, focus.value() * .85)); g.drawRect(x, y, width - 1, height - 1);
            }
        });
        box.addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent event) { focus.to(1, 150); }
            @Override public void focusLost(FocusEvent event) { focus.to(0, 170); }
        });
        box.addPopupMenuListener(new PopupMenuListener() {
            public void popupMenuWillBecomeVisible(PopupMenuEvent event) { opened.to(1, 160); }
            public void popupMenuWillBecomeInvisible(PopupMenuEvent event) { opened.to(0, 160); }
            public void popupMenuCanceled(PopupMenuEvent event) { opened.to(0, 160); }
        });
        box.setUI(new BasicComboBoxUI() {
            @Override protected JButton createArrowButton() {
                JButton arrow = new JButton(new Icon() {
                    public int getIconWidth() { return 10; }
                    public int getIconHeight() { return 8; }
                    public void paintIcon(Component component, Graphics graphics, int x, int y) {
                        Graphics2D g = (Graphics2D) graphics.create();
                        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        g.rotate(Math.PI * opened.value(), x + 4, y + 4); g.setColor(MUTED); g.setStroke(new BasicStroke(1.2f));
                        g.drawLine(x, y + 2, x + 4, y + 6); g.drawLine(x + 4, y + 6, x + 8, y + 2); g.dispose();
                    }
                });
                arrow.setBorder(new EmptyBorder(0, 4, 0, 12)); arrow.setBackground(SURFACE); arrow.setFocusPainted(false); return arrow;
            }
            @Override protected ComboPopup createPopup() {
                return new BasicComboPopup(comboBox) {
                    private double alpha = 1;
                    private final Motion.Tween reveal = new Motion.Tween(1, value -> { alpha = value; repaint(); });
                    @Override public void show() { reveal.snap(0); super.show(); reveal.to(1, 140); }
                    @Override protected void paintChildren(Graphics graphics) {
                        Graphics2D g = (Graphics2D) graphics.create(); g.setComposite(AlphaComposite.SrcOver.derive((float) alpha));
                        g.translate(0, -4 * (1 - alpha)); super.paintChildren(g); g.dispose();
                    }
                };
            }
        });
    }
    public static JScrollPane scroll(JComponent view) {
        JScrollPane pane = new JScrollPane(view); pane.setWheelScrollingEnabled(false);
        pane.setBorder(BorderFactory.createLineBorder(LINE));
        JScrollBar bar = pane.getVerticalScrollBar(); bar.setUnitIncrement(24);
        Motion.Tween position = new Motion.Tween(0, value -> bar.setValue((int) Math.round(value)));
        pane.addMouseWheelListener(event -> {
            if (!bar.isVisible() || event.isShiftDown()) return;
            double movement = event.getPreciseWheelRotation() * (event.getScrollType() == MouseWheelEvent.WHEEL_BLOCK_SCROLL ? bar.getBlockIncrement() : bar.getUnitIncrement() * event.getScrollAmount());
            double target = (Double) pane.getClientProperty("rise.scrollTarget") == null ? bar.getValue() : (Double) pane.getClientProperty("rise.scrollTarget");
            if (Math.abs(bar.getValue() - position.value()) > 2) target = bar.getValue();
            target = Math.max(bar.getMinimum(), Math.min(bar.getMaximum() - bar.getVisibleAmount(), target + movement));
            if (Motion.activeCount() == 0 || Math.abs(bar.getValue() - position.value()) > 2) position.snap(bar.getValue());
            pane.putClientProperty("rise.scrollTarget", target); position.to(target, 150); event.consume();
        });
        pane.addHierarchyListener(event -> { if (!pane.isShowing()) position.snap(bar.getValue()); });
        return pane;
    }

    private static final class FlatButton extends JButton {
        private final boolean primary;
        private final Motion.Tween hover = new Motion.Tween(0, value -> repaint());
        private final Motion.Tween press = new Motion.Tween(0, value -> repaint());
        private final Motion.Tween focus = new Motion.Tween(0, value -> repaint());
        private final Motion.Tween disabled = new Motion.Tween(0, value -> repaint());
        private final Motion.Tween loading = new Motion.Tween(0, value -> repaint());
        private final Motion.Pulse spinner = new Motion.Pulse(this::repaint);
        FlatButton(String text, boolean primary) {
            super(text); this.primary = primary;
            setContentAreaFilled(false); setBorderPainted(false); setFocusPainted(false);
            setForeground(primary ? BACKGROUND : TEXT); setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setBorder(new EmptyBorder(11, 16, 11, 16)); setRolloverEnabled(true);
            getModel().addChangeListener(event -> {
                hover.to(getModel().isRollover() && isEnabled() ? 1 : 0, 150);
                press.to(getModel().isPressed() && getModel().isArmed() ? 1 : 0, getModel().isPressed() ? 75 : 160);
                disabled.to(isEnabled() ? 0 : 1, 170);
            });
            addFocusListener(new FocusAdapter() {
                @Override public void focusGained(FocusEvent event) { focus.to(1, 140); }
                @Override public void focusLost(FocusEvent event) { focus.to(0, 160); }
            });
            addPropertyChangeListener("rise.busy", event -> {
                boolean busy = Boolean.TRUE.equals(event.getNewValue()); loading.to(busy ? 1 : 0, 180);
                if (busy && isShowing()) spinner.start(); else spinner.stop();
            });
            addHierarchyListener(event -> {
                if (isShowing() && Boolean.TRUE.equals(getClientProperty("rise.busy"))) spinner.start(); else if (!isShowing()) spinner.stop();
            });
        }
        @Override protected void paintComponent(Graphics graphics) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            double pressed = press.value(), busy = loading.value();
            double scale = 1 - pressed * .025; g.translate(getWidth() * (1 - scale) / 2, getHeight() * (1 - scale) / 2); g.scale(scale, scale);
            Color normal = primary ? ACCENT : Boolean.TRUE.equals(getClientProperty("rise.chrome")) ? BACKGROUND : SURFACE;
            Color over = primary ? new Color(174, 207, 250) : Boolean.TRUE.equals(getClientProperty("rise.danger")) ? new Color(114, 42, 44) : new Color(34, 39, 44);
            Color fill = mix(normal, over, hover.value());
            fill = mix(fill, primary ? new Color(122, 167, 226) : new Color(44, 49, 54), pressed);
            fill = mix(fill, new Color(57, 65, 73), disabled.value() * (busy > .01 ? .35 : 1));
            g.setColor(fill); g.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
            if (focus.value() > .01) { g.setColor(mix(fill, primary ? TEXT : ACCENT, focus.value())); g.drawRoundRect(1, 1, getWidth() - 3, getHeight() - 3, 7, 7); }
            g.translate(8 * busy, 0); super.paintComponent(g); g.translate(-8 * busy, 0);
            if (busy > .01) {
                g.setComposite(AlphaComposite.SrcOver.derive((float) busy)); g.setColor(primary ? BACKGROUND : TEXT);
                g.setStroke(new BasicStroke(1.6f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                int angle = Motion.enabled() ? (int) (-360 * ((System.nanoTime() / 1_000_000L % 900) / 900.0)) : 90;
                g.drawArc(16, (getHeight() - 12) / 2, 12, 12, angle, 265);
            }
            g.dispose();
        }
        @Override public void removeNotify() { spinner.stop(); hover.snap(0); press.snap(0); focus.snap(0); disabled.snap(isEnabled() ? 0 : 1); loading.snap(Boolean.TRUE.equals(getClientProperty("rise.busy")) ? 1 : 0); super.removeNotify(); }
    }
}
