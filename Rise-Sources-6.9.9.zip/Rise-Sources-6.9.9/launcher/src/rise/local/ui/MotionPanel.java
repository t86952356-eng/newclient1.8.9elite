package rise.local.ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public final class MotionPanel extends JPanel {
    private double amount = 1;
    private final int distance;
    private final Motion.Tween motion = new Motion.Tween(1, value -> { amount = value; repaint(); });
    public MotionPanel(JComponent content, int distance) {
        super(new BorderLayout()); this.distance = distance;
        setOpaque(false); add(content, BorderLayout.CENTER);
    }
    public void reveal(int delay) { motion.snap(0); motion.to(1, 220, delay, null); }
    public void dismiss(Runnable completed) { motion.to(0, 120, 0, completed); }
    public void refresh() { if (motion.value() > .98) motion.snap(.65); motion.to(1, 140); }
    public static MotionPanel entrance(JComponent content, int delay) {
        MotionPanel panel = new MotionPanel(content, 8); panel.motion.snap(0);
        panel.addHierarchyListener(event -> { if ((event.getChangeFlags() & HierarchyEvent.SHOWING_CHANGED) != 0 && panel.isShowing()) panel.reveal(delay); });
        return panel;
    }
    @Override protected void paintChildren(Graphics graphics) {
        Graphics2D g = (Graphics2D) graphics.create();
        float parentAlpha = g.getComposite() instanceof AlphaComposite composite ? composite.getAlpha() : 1;
        g.setComposite(AlphaComposite.SrcOver.derive(parentAlpha * (float) Math.max(0, Math.min(1, amount))));
        g.translate(0, distance * (1 - amount)); super.paintChildren(g); g.dispose();
    }
    @Override public void removeNotify() { motion.snap(1); super.removeNotify(); }
    public static void install(JDialog dialog, JComponent content) {
        MotionPanel panel = new MotionPanel(content, 8); panel.setOpaque(true); panel.setBackground(LauncherTheme.BACKGROUND); panel.motion.snap(0); dialog.setContentPane(panel);
        dialog.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        dialog.addComponentListener(new ComponentAdapter() { @Override public void componentShown(ComponentEvent event) { panel.reveal(0); } });
        dialog.addWindowListener(new WindowAdapter() { @Override public void windowClosing(WindowEvent event) { close(dialog); } });
        dialog.getRootPane().registerKeyboardAction(event -> close(dialog), KeyStroke.getKeyStroke("ESCAPE"), JComponent.WHEN_IN_FOCUSED_WINDOW);
    }
    public static void close(Window window) {
        if (window instanceof RootPaneContainer root && root.getContentPane() instanceof MotionPanel panel) {
            if (Boolean.TRUE.equals(panel.getClientProperty("rise.closing"))) return;
            panel.putClientProperty("rise.closing", true);
            panel.dismiss(() -> { panel.putClientProperty("rise.closing", false); window.dispose(); });
        } else window.dispose();
    }
}
