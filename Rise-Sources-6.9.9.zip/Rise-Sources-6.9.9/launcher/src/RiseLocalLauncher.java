import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.plaf.FontUIResource;
import rise.local.ui.LauncherTheme;
import rise.local.ui.Motion;
import rise.local.ui.MotionLabel;
import rise.local.ui.MotionPanel;

public final class RiseLocalLauncher {
    private final Path root;
    private final Path dataRoot;
    private final JFrame frame=new JFrame("Rise Launcher");
    private final JTextField username=new JTextField("User");
    private final JTextField javaPath=new JTextField();
    private final JTextField assetsPath=new JTextField();
    private final JComboBox<Integer> memory=new JComboBox<>(new Integer[]{2048,3072,4096,6144,8192});
    private final JCheckBox rawMouse=new JCheckBox("Raw mouse input",true);
    private final JTextArea log=new JTextArea();
    private final JLabel status=new MotionLabel("Ready");
    private final JButton launch=LauncherTheme.button("Launch Rise",true);
    private volatile Process game;
    private Path latestLog;
    private final Properties settings=new Properties();
    private JDialog logWindow;
    private JScrollPane logScroll;
    private final StringBuilder pendingLog=new StringBuilder();
    private final javax.swing.Timer logFlush=new javax.swing.Timer(50,event->flushLog());
    private boolean logFlushQueued;
    private volatile boolean uiClosed;

    private RiseLocalLauncher(Path directory)throws Exception {
        root=directory;dataRoot=Paths.get(System.getProperty("rise.launcher.data",root.resolve("runtime").toString())).toAbsolutePath().normalize();loadSettings();
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);frame.setUndecorated(true);frame.setSize(800,510);frame.setResizable(false);frame.setBackground(LauncherTheme.BACKGROUND);
        JPanel content=new JPanel(new BorderLayout());content.setBackground(LauncherTheme.BACKGROUND);
        content.setBorder(BorderFactory.createLineBorder(LauncherTheme.LINE));MotionPanel rootPanel=new MotionPanel(content,0);rootPanel.setOpaque(true);rootPanel.setBackground(LauncherTheme.BACKGROUND);frame.setContentPane(rootPanel);
        JPanel chrome=LauncherTheme.panel(new BorderLayout());chrome.setPreferredSize(new Dimension(800,36));
        JPanel windowActions=LauncherTheme.panel(new FlowLayout(FlowLayout.RIGHT,0,0));
        windowActions.add(windowButton(false));windowActions.add(windowButton(true));chrome.add(windowActions,BorderLayout.EAST);content.add(chrome,BorderLayout.NORTH);
        MouseAdapter drag=new MouseAdapter(){private Point point;public void mousePressed(MouseEvent event){point=event.getPoint();}public void mouseDragged(MouseEvent event){Point screen=event.getLocationOnScreen();frame.setLocation(screen.x-point.x,screen.y-point.y);}};
        chrome.addMouseListener(drag);chrome.addMouseMotionListener(drag);
        JPanel main=LauncherTheme.panel(new BorderLayout(0,32));main.setBorder(new EmptyBorder(8,36,30,36));content.add(main,BorderLayout.CENTER);
        JLabel title=LauncherTheme.label("Rise",40,LauncherTheme.TEXT);title.setFont(title.getFont().deriveFont(Font.BOLD));main.add(MotionPanel.entrance(title,0),BorderLayout.NORTH);
        JPanel center=LauncherTheme.panel(new GridBagLayout());GridBagConstraints c=new GridBagConstraints();c.fill=GridBagConstraints.HORIZONTAL;c.anchor=GridBagConstraints.NORTHWEST;
        c.gridx=0;c.gridy=0;c.weightx=.72;c.insets=new Insets(0,0,9,26);center.add(LauncherTheme.label("Player name",12,LauncherTheme.MUTED),c);
        c.gridx=1;c.weightx=.28;c.insets=new Insets(0,0,9,0);center.add(LauncherTheme.label("Memory",12,LauncherTheme.MUTED),c);
        LauncherTheme.field(username);username.setFont(username.getFont().deriveFont(16f));c.gridx=0;c.gridy=1;c.weightx=.72;c.insets=new Insets(0,0,30,26);center.add(username,c);
        memory.setPreferredSize(new Dimension(180,46));memory.setBorder(BorderFactory.createLineBorder(LauncherTheme.LINE));memory.setFocusable(true);
        memory.setRenderer(new DefaultListCellRenderer(){public Component getListCellRendererComponent(JList<?> list,Object value,int index,boolean selected,boolean focus){JLabel label=(JLabel)super.getListCellRendererComponent(list,value,index,selected,focus);label.setText(value==null?"":((Integer)value/1024)+" GB");label.setBorder(new EmptyBorder(10,12,10,12));return label;}});
        LauncherTheme.combo(memory);
        c.gridx=1;c.weightx=.28;c.insets=new Insets(0,0,30,0);center.add(memory,c);
        JPanel config=LauncherTheme.panel(new BorderLayout(12,9));config.add(LauncherTheme.label("Config",12,LauncherTheme.MUTED),BorderLayout.NORTH);
        String profile=Files.isRegularFile(dataRoot.resolve("game/Rise/configs/latest.json"))?"Saved profile":"Hypixel 1.8";
        config.add(LauncherTheme.label(profile,16,LauncherTheme.TEXT),BorderLayout.CENTER);
        JButton configs=LauncherTheme.button("Configs",false);configs.addActionListener(e->{try{new rise.local.config.OnlineConfigDialog(frame,dataRoot.resolve("game")).setVisible(true);}catch(Exception error){showError(error,"Configs");}});config.add(configs,BorderLayout.EAST);
        c.gridx=0;c.gridy=2;c.weightx=.72;c.insets=new Insets(0,0,0,26);center.add(config,c);
        LauncherTheme.toggle(rawMouse);rawMouse.setBorder(new EmptyBorder(17,0,0,0));
        rawMouse.setToolTipText("Applies on the next launch.");c.gridx=1;c.weightx=.28;c.insets=new Insets(0,0,0,0);center.add(rawMouse,c);
        c.gridx=0;c.gridy=3;c.gridwidth=2;c.weighty=1;center.add(Box.createVerticalGlue(),c);main.add(MotionPanel.entrance(center,35),BorderLayout.CENTER);
        log.setEditable(false);log.setLineWrap(true);log.setWrapStyleWord(true);log.setFont(log.getFont().deriveFont(12f));log.setMargin(new Insets(14,14,14,14));
        ((javax.swing.text.DefaultCaret)log.getCaret()).setUpdatePolicy(javax.swing.text.DefaultCaret.NEVER_UPDATE);
        JPanel footer=LauncherTheme.panel(new BorderLayout(16,16));footer.setBorder(new CompoundBorder(BorderFactory.createMatteBorder(1,0,0,0,LauncherTheme.LINE),new EmptyBorder(20,0,0,0)));
        JPanel left=LauncherTheme.panel(new BorderLayout(0,14));status.setText("Ready");status.setForeground(LauncherTheme.MUTED);status.setPreferredSize(new Dimension(440,18));left.add(status,BorderLayout.NORTH);
        JPanel links=LauncherTheme.panel(new FlowLayout(FlowLayout.LEFT,8,0));links.setBorder(new EmptyBorder(0,-8,0,0));
        JButton settingsButton=LauncherTheme.button("Settings",false);settingsButton.addActionListener(e->settingsDialog());links.add(settingsButton);
        JButton folder=LauncherTheme.button("Game folder",false);folder.addActionListener(e->open(dataRoot.resolve("game")));links.add(folder);
        JButton logs=LauncherTheme.button("Logs",false);logs.addActionListener(e->logsDialog());links.add(logs);left.add(links,BorderLayout.SOUTH);footer.add(left,BorderLayout.WEST);
        launch.setFont(launch.getFont().deriveFont(Font.BOLD,15f));launch.setPreferredSize(new Dimension(205,58));
        JPanel primary=LauncherTheme.panel(new BorderLayout());primary.setBorder(new EmptyBorder(16,0,0,0));primary.add(launch,BorderLayout.SOUTH);footer.add(primary,BorderLayout.EAST);launch.addActionListener(e->launch());main.add(MotionPanel.entrance(footer,70),BorderLayout.SOUTH);frame.getRootPane().setDefaultButton(launch);
        username.getDocument().addDocumentListener(new javax.swing.event.DocumentListener(){public void insertUpdate(javax.swing.event.DocumentEvent event){validate();}public void removeUpdate(javax.swing.event.DocumentEvent event){validate();}public void changedUpdate(javax.swing.event.DocumentEvent event){validate();}private void validate(){if(username.getText().trim().matches("[A-Za-z0-9_]{1,16}")&&Boolean.TRUE.equals(username.getClientProperty("rise.invalid"))){username.putClientProperty("rise.invalid",false);if(game==null)status.setText("Ready");}}});
        frame.addWindowListener(new WindowAdapter(){public void windowOpened(WindowEvent event){username.requestFocusInWindow();username.selectAll();}public void windowClosing(WindowEvent event){MotionPanel.close(frame);}public void windowClosed(WindowEvent event){uiClosed=true;logFlush.stop();try{saveSettings();}catch(Exception ignored){}}});
        frame.setLocationRelativeTo(null);append("Rise "+ClientRelease.VERSION);
    }

    private JButton windowButton(boolean close) {
        JButton button=LauncherTheme.windowButton(new Icon(){public int getIconWidth(){return 12;}public int getIconHeight(){return 12;}public void paintIcon(Component component,Graphics graphics,int x,int y){Graphics2D g=(Graphics2D)graphics.create();g.setColor(LauncherTheme.MUTED);g.setStroke(new BasicStroke(1.2f));if(close){g.drawLine(x+2,y+2,x+10,y+10);g.drawLine(x+10,y+2,x+2,y+10);}else g.drawLine(x+1,y+8,x+11,y+8);g.dispose();}},close);
        button.setPreferredSize(new Dimension(44,34));button.setToolTipText(close?"Close":"Minimize");button.getAccessibleContext().setAccessibleName(close?"Close":"Minimize");button.addActionListener(event->{if(close)MotionPanel.close(frame);else frame.setState(Frame.ICONIFIED);});return button;
    }
    private void showError(Exception error,String title){JOptionPane.showMessageDialog(frame,error.getMessage(),title,JOptionPane.ERROR_MESSAGE);}
    private void settingsDialog() {
        JDialog dialog=new JDialog(frame,"Settings",true);JPanel body=new JPanel(new GridBagLayout());body.setBorder(new EmptyBorder(22,24,22,24));
        GridBagConstraints c=new GridBagConstraints();c.insets=new Insets(8,0,8,12);c.fill=GridBagConstraints.HORIZONTAL;
        LauncherTheme.field(javaPath);LauncherTheme.field(assetsPath);
        JButton javaBrowse=LauncherTheme.button("Browse",false);javaBrowse.addActionListener(e->browse(javaPath,false));row(body,c,0,"Java 21+",javaPath,javaBrowse);
        JButton assetsBrowse=LauncherTheme.button("Browse",false);assetsBrowse.addActionListener(e->browse(assetsPath,true));row(body,c,1,"Assets",assetsPath,assetsBrowse);
        c.gridx=0;c.gridy=2;c.gridwidth=3;body.add(LauncherTheme.label(dataRoot.toString(),11,LauncherTheme.MUTED),c);
        JCheckBox animations=new JCheckBox("Animations",Motion.enabled());LauncherTheme.toggle(animations);animations.addActionListener(e->Motion.setEnabled(animations.isSelected()));c.gridy=3;c.anchor=GridBagConstraints.WEST;c.fill=GridBagConstraints.NONE;body.add(animations,c);
        JButton done=LauncherTheme.button("Done",true);done.addActionListener(e->{try{saveSettings();MotionPanel.close(dialog);}catch(Exception error){showError(error,"Settings");}});c.gridy=4;c.anchor=GridBagConstraints.EAST;c.fill=GridBagConstraints.NONE;body.add(done,c);
        MotionPanel.install(dialog,body);dialog.setSize(660,320);dialog.setResizable(false);dialog.setLocationRelativeTo(frame);dialog.setVisible(true);
    }
    private void logsDialog() {
        if(logWindow==null){logWindow=new JDialog(frame,"Logs",false);JPanel body=new JPanel(new BorderLayout(0,12));body.setBorder(new EmptyBorder(16,16,16,16));logScroll=LauncherTheme.scroll(log);body.add(logScroll,BorderLayout.CENTER);JButton latest=LauncherTheme.button("Open latest log",false);latest.addActionListener(e->open(latestLog==null?dataRoot.resolve("logs"):latestLog));body.add(latest,BorderLayout.SOUTH);MotionPanel.install(logWindow,body);logWindow.setSize(720,400);}
        logWindow.setLocationRelativeTo(frame);logWindow.setVisible(true);
    }
    private void row(JPanel panel,GridBagConstraints c,int y,String name,JComponent input,JButton button) {
        c.gridy=y;c.gridx=0;c.gridwidth=1;c.weightx=0;panel.add(new JLabel(name),c);c.gridx=1;c.weightx=1;input.setPreferredSize(new Dimension(200,44));panel.add(input,c);
        c.gridx=2;c.weightx=0;if(button!=null)panel.add(button,c);
    }
    private void loadSettings()throws Exception {
        Path path=dataRoot.resolve("launcher.properties");if(!Files.exists(path))path=root.resolve("launcher/settings.properties");if(Files.exists(path))try(InputStream input=Files.newInputStream(path)){settings.load(input);}
        username.setText(settings.getProperty("username","User"));memory.setSelectedItem(Integer.valueOf(settings.getProperty("memory","2048")));
        Motion.setEnabled(Boolean.parseBoolean(settings.getProperty("animations","true")));
        rawMouse.setSelected(Boolean.parseBoolean(settings.getProperty("rawMouse","true")));
        Path javaDefault=defaultJava(root),defaultAssets=defaultAssets(root);
        String savedJava=settings.getProperty("java","bundled"),savedAssets=settings.getProperty("assets","bundled");
        javaPath.setText(savedJava.equals("bundled")||!Files.isRegularFile(Paths.get(savedJava))?javaDefault.toString():savedJava);
        assetsPath.setText(savedAssets.equals("bundled")||!Files.isRegularFile(Paths.get(savedAssets).resolve("indexes/1.8.json"))?defaultAssets.toString():savedAssets);
    }
    private void saveSettings()throws Exception {
        settings.setProperty("username",username.getText().trim());settings.setProperty("memory",memory.getSelectedItem().toString());
        settings.setProperty("rawMouse",Boolean.toString(rawMouse.isSelected()));
        settings.setProperty("animations",Boolean.toString(Motion.enabled()));
        settings.setProperty("java",Paths.get(javaPath.getText().trim()).equals(defaultJava(root))?"bundled":javaPath.getText().trim());
        settings.setProperty("assets",Paths.get(assetsPath.getText().trim()).equals(defaultAssets(root))?"bundled":assetsPath.getText().trim());
        Files.createDirectories(dataRoot);try(OutputStream output=Files.newOutputStream(dataRoot.resolve("launcher.properties"))){settings.store(output,"Rise local launcher");}
    }
    private void browse(JTextField field,boolean directory) {
        JFileChooser chooser=new JFileChooser();chooser.setFileSelectionMode(directory?JFileChooser.DIRECTORIES_ONLY:JFileChooser.FILES_ONLY);if(!field.getText().isBlank())chooser.setSelectedFile(new File(field.getText()));
        if(chooser.showOpenDialog(frame)==JFileChooser.APPROVE_OPTION)field.setText(chooser.getSelectedFile().getAbsolutePath());
    }
    private void open(Path path) {try{Files.createDirectories(Files.isRegularFile(path)?path.getParent():path);Desktop.getDesktop().open(path.toFile());}catch(Exception error){append(error.toString());}}
    private void append(String text) {
        if(uiClosed)return;
        synchronized(pendingLog){pendingLog.append(text).append('\n');if(pendingLog.length()>120000)pendingLog.delete(0,pendingLog.length()-60000);if(!logFlushQueued){logFlushQueued=true;SwingUtilities.invokeLater(()->{if(!uiClosed)logFlush.start();});}}
    }
    private void flushLog() {
        String batch;synchronized(pendingLog){batch=pendingLog.toString();pendingLog.setLength(0);logFlushQueued=false;}logFlush.stop();
        boolean follow=logScroll==null||logScroll.getVerticalScrollBar().getValue()+logScroll.getVerticalScrollBar().getVisibleAmount()>=logScroll.getVerticalScrollBar().getMaximum()-8;
        log.append(batch);if(log.getDocument().getLength()>120000)log.replaceRange("",0,60000);if(follow)log.setCaretPosition(log.getDocument().getLength());
    }
    private void launch() {
        String name=username.getText().trim();if(!name.matches("[A-Za-z0-9_]{1,16}")){username.putClientProperty("rise.invalid",true);username.requestFocusInWindow();status.setText("Use 1-16 letters, numbers or underscores.");return;}
        String executable=javaPath.getText().trim();Path assets=Paths.get(assetsPath.getText().trim());int ram=(Integer)memory.getSelectedItem();boolean raw=rawMouse.isSelected();
        try{saveSettings();}catch(Exception error){showError(error,"Settings");return;}
        launch.setEnabled(false);LauncherTheme.busy(launch,true);launch.setText("Starting...");status.setText("Preparing Rise...");
        Thread worker=new Thread(()->{
            try {
                RunningGame running=startClient(root,dataRoot,assets,executable,name,ram,raw);game=running.process();latestLog=running.log();
                append("Launching "+name+" with "+ram+" MiB. Log: "+latestLog.getFileName());
                SwingUtilities.invokeLater(()->status.setText("Starting Rise..."));
                try(BufferedReader reader=Files.newBufferedReader(latestLog,StandardCharsets.UTF_8)) {
                    while(true){String line=reader.readLine();if(line!=null){append(line);if(line.equals("[Launcher] Client ready."))SwingUtilities.invokeLater(()->{LauncherTheme.busy(launch,false);launch.setText("Running");status.setText("Rise is running");});}else if(game.isAlive())Thread.sleep(100);else break;}
                }
                int exit=game.waitFor();append("Client exited ("+exit+").");SwingUtilities.invokeLater(()->status.setText(exit==0?"Ready to launch":"Client exited with an error. Open the latest log."));
            }catch(Exception error){append(error.toString());SwingUtilities.invokeLater(()->{status.setText("Launch failed");JOptionPane.showMessageDialog(frame,error.getMessage(),"Unable to launch",JOptionPane.ERROR_MESSAGE);});}
            finally{game=null;SwingUtilities.invokeLater(()->{LauncherTheme.busy(launch,false);launch.setText("Launch Rise");launch.setEnabled(true);});}
        },"client-launcher");worker.setDaemon(true);worker.start();
    }
    private static void require(Path path,String label)throws IOException {if(!Files.isRegularFile(path))throw new IOException(label+" not found: "+path);}
    private record RunningGame(Process process,Path log) {}
    private static Path defaultJava(Path root) {
        Path bundled=root.resolve("runtime/java/bin/java.exe");return Files.isRegularFile(bundled)?bundled:Paths.get(System.getProperty("java.home"),"bin","java.exe");
    }
    private static Path defaultAssets(Path root) {
        Path bundled=root.resolve("runtime/assets");String appdata=System.getenv("APPDATA");
        return Files.isRegularFile(bundled.resolve("indexes/1.8.json"))||appdata==null?bundled:Paths.get(appdata,".minecraft","assets");
    }
    private static RunningGame startClient(Path root,Path dataRoot,Path assets,String executable,String name,int ram,boolean raw)throws Exception {
        if(!name.matches("[A-Za-z0-9_]{1,16}"))throw new IOException("Invalid player name.");
        require(Paths.get(executable),"Java executable");require(root.resolve("launcher/offline-patches.jar"),"Local patch");require(root.resolve("artifacts/client-restored.jar"),"Client JAR");require(root.resolve("artifacts/libraries.jar"),"Libraries");
        require(assets.resolve("indexes/1.8.json"),"Minecraft 1.8 assets index");
        Process version=new ProcessBuilder(executable,"-version").redirectErrorStream(true).start();
        if(!version.waitFor(8,TimeUnit.SECONDS)){version.destroyForcibly();throw new IOException("Java version check timed out.");}
        String result=new String(version.getInputStream().readAllBytes(),StandardCharsets.UTF_8);
        java.util.regex.Matcher matcher=java.util.regex.Pattern.compile("version \\\"(\\d+)").matcher(result);
        if(!matcher.find()||Integer.parseInt(matcher.group(1))<21)throw new IOException("Rise requires Java 21 or newer.\n"+result);
        Path natives=root.resolve("runtime/natives"),data=dataRoot.resolve("game"),logs=dataRoot.resolve("logs");Files.createDirectories(data);Files.createDirectories(logs);
        require(natives.resolve("lwjgl64.dll"),"LWJGL native library");
        Path self=Paths.get(RiseLocalLauncher.class.getProtectionDomain().getCodeSource().getLocation().toURI());
        String classpath=String.join(File.pathSeparator,root.resolve("launcher/offline-patches.jar").toString(),root.resolve("artifacts/client-restored.jar").toString(),self.toString(),root.resolve("artifacts/libraries.jar").toString());
        List<String> command=new ArrayList<>(Arrays.asList(executable,"-Xmx"+ram+"M","--enable-native-access=ALL-UNNAMED","-Drise.offline.username="+name,"-Drise.rawMouse="+raw,"-Djava.library.path="+natives,"-cp",classpath,"OfflineBootstrap","--gameDir",data.toString(),"--assetsDir",assets.toString(),"--assetIndex","1.8","--width","1100","--height","700"));
        Path output=logs.resolve("client-"+LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss-SSS"))+".log");
        ProcessBuilder builder=new ProcessBuilder(command).directory(data.toFile()).redirectErrorStream(true).redirectOutput(output.toFile());
        String searchPath=builder.environment().getOrDefault("PATH","");
        builder.environment().put("PATH",natives+File.pathSeparator+Paths.get(executable).getParent()+File.pathSeparator+searchPath);
        Process process=builder.start();
        return new RunningGame(process,output);
    }
    private static void theme()throws Exception {
        LauncherTheme.install();
    }
    public static void main(String[] arguments)throws Exception {
        Path location=Paths.get(RiseLocalLauncher.class.getProtectionDomain().getCodeSource().getLocation().toURI());Path project=Files.isDirectory(location)?location:location.getParent();
        while(project!=null&&!Files.isRegularFile(project.resolve("artifacts/client-restored.jar")))project=project.getParent();if(project==null)throw new IOException("Place the launcher in the Rise project folder.");
        if(Arrays.asList(arguments).contains("--launch-only")) {
            Path data=Paths.get(System.getProperty("rise.launcher.data",project.resolve("runtime").toString()));
            RunningGame running=startClient(project,data,defaultAssets(project),defaultJava(project).toString(),System.getProperty("rise.offline.username","User"),2048,Boolean.parseBoolean(System.getProperty("rise.rawMouse","true")));
            System.out.println("Client PID "+running.process().pid()+"; log "+running.log());return;
        }
        final Path directory=project;theme();SwingUtilities.invokeLater(()->{try{new RiseLocalLauncher(directory).frame.setVisible(true);}catch(Exception error){JOptionPane.showMessageDialog(null,error.toString());}});
    }
}
