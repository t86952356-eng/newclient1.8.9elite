using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

internal static class PortableLauncher {
    const string Magic = "RISE-PACKAGE-1\0\0";
    static string dataDirectory;
    static string executable;
    static bool quiet;

    [STAThread]
    static int Main(string[] args) {
        executable = Assembly.GetExecutingAssembly().Location;
        quiet = args.Contains("--extract-only") || args.Contains("--verify") || args.Contains("--launch-only");
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        try {
            if (!Environment.Is64BitOperatingSystem) throw new IOException("Rise Portable requires 64-bit Windows.");
            int dataOption = Array.IndexOf(args, "--data-dir");
            dataDirectory = Path.GetFullPath(dataOption >= 0 && dataOption + 1 < args.Length ? args[dataOption + 1] : Path.Combine(Path.GetDirectoryName(executable), "RiseData"));
            Directory.CreateDirectory(dataDirectory);
            string runtime = null;
            if (quiet) runtime = Prepare(null, args.Contains("--verify"));
            else if ((runtime = PreparedRuntime()) == null) using (var progress = new PreparationWindow()) {
                Exception failure = null;
                progress.Shown += delegate {
                    Task.Run(delegate {
                        try { runtime = Prepare(progress.UpdateProgress, false); }
                        catch (Exception error) { failure = error; }
                        finally { progress.BeginInvoke(new Action(progress.Close)); }
                    });
                };
                Application.Run(progress);
                if (failure != null) throw failure;
            }
            if (args.Contains("--extract-only")) return 0;
            if (args.Contains("--verify")) return Verify(runtime);
            Launch(runtime, args.Contains("--launch-only"));
            return 0;
        } catch (Exception error) {
            string message = error.ToString();
            try { File.AppendAllText(Path.Combine(dataDirectory ?? Path.GetTempPath(), "bootstrap.log"), DateTime.Now.ToString("s") + " " + message + Environment.NewLine); } catch { }
            if (!quiet) MessageBox.Show(error.Message, "Rise Launcher", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return 1;
        }
    }

    static string Hex(byte[] value) { return BitConverter.ToString(value).Replace("-", "").ToLowerInvariant(); }
    static string PreparedRuntime() {
        using (var source = new FileStream(executable, FileMode.Open, FileAccess.Read, FileShare.Read)) {
            if (source.Length < 64) return null;
            source.Position = source.Length - 64;
            var trailer = new BinaryReader(source);
            if (Encoding.ASCII.GetString(trailer.ReadBytes(16)) != Magic) return null;
            trailer.ReadInt64();
            string digest = Hex(trailer.ReadBytes(32));
            string target = Path.Combine(dataDirectory, ".runtime", digest.Substring(0, 20));
            string marker = Path.Combine(target, ".ready");
            return File.Exists(marker) && File.ReadAllText(marker).Trim() == digest && Essentials(target) ? target : null;
        }
    }
    static string Prepare(Action<int, string> progress, bool verify) {
        using (var source = new FileStream(executable, FileMode.Open, FileAccess.Read, FileShare.Read)) {
            if (source.Length < 64) throw new IOException("The portable package is incomplete.");
            source.Position = source.Length - 64;
            var trailer = new BinaryReader(source);
            if (Encoding.ASCII.GetString(trailer.ReadBytes(16)) != Magic) throw new IOException("The portable package footer is missing.");
            long length = trailer.ReadInt64();
            byte[] expected = trailer.ReadBytes(32);
            long count = trailer.ReadInt64();
            long offset = source.Length - 64 - length;
            if (offset < 0 || length <= 0 || count <= 0) throw new IOException("Invalid portable package length.");
            string digest = Hex(expected);
            string cache = Path.Combine(dataDirectory, ".runtime");
            Directory.CreateDirectory(cache);
            string target = Path.Combine(cache, digest.Substring(0, 20));
            string marker = Path.Combine(target, ".ready");
            string lockFile = Path.Combine(cache, "extract.lock");
            using (var extractionLock = Lock(lockFile)) {
                if (File.Exists(marker) && File.ReadAllText(marker).Trim() == digest && Essentials(target)) {
                    if (verify) VerifyFiles(target);
                    return target;
                }
                if (progress != null) progress(0, "Checking files...");
                using (var segment = new PackageStream(source, offset, length))
                using (var algorithm = SHA256.Create()) {
                    if (!algorithm.ComputeHash(segment).SequenceEqual(expected)) throw new IOException("The portable package checksum does not match. Copy the EXE again.");
                }
                string partial = target + ".partial";
                if (Directory.Exists(partial)) Directory.Delete(partial, true);
                Directory.CreateDirectory(partial);
                using (var segment = new PackageStream(source, offset, length))
                using (var archive = new ZipArchive(segment, ZipArchiveMode.Read, true)) {
                    long completed = 0, total = archive.Entries.Sum(entry => entry.Length);
                    byte[] buffer = new byte[131072];
                    string prefix = Path.GetFullPath(partial) + Path.DirectorySeparatorChar;
                    foreach (var entry in archive.Entries) {
                        string destination = Path.GetFullPath(Path.Combine(partial, entry.FullName.Replace('/', Path.DirectorySeparatorChar)));
                        if (!destination.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) throw new IOException("Invalid package path.");
                        if (entry.FullName.EndsWith("/")) { Directory.CreateDirectory(destination); continue; }
                        Directory.CreateDirectory(Path.GetDirectoryName(destination));
                        using (var input = entry.Open())
                        using (var output = new FileStream(destination, FileMode.Create, FileAccess.Write, FileShare.None)) {
                            int read;
                            while ((read = input.Read(buffer, 0, buffer.Length)) != 0) {
                                output.Write(buffer, 0, read);
                                completed += read;
                            }
                        }
                        if (progress != null) progress((int)(completed * 95 / Math.Max(1, total)), "Extracting files...");
                    }
                    if (archive.Entries.Count != count) throw new IOException("The portable package file count does not match.");
                }
                if (progress != null) progress(96, "Verifying the extracted files...");
                VerifyFiles(partial);
                File.WriteAllText(Path.Combine(partial, ".ready"), digest, Encoding.ASCII);
                if (Directory.Exists(target)) Directory.Delete(target, true);
                Directory.Move(partial, target);
                if (progress != null) progress(100, "Starting the launcher...");
                return target;
            }
        }
    }

    static FileStream Lock(string path) {
        for (int attempt = 0; ; attempt++) {
            try { return new FileStream(path, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None); }
            catch (IOException) { if (attempt >= 120) throw; Thread.Sleep(250); }
        }
    }
    static bool Essentials(string root) {
        return new[] { "RiseLocalLauncher.jar", "launcher/offline-patches.jar", "artifacts/client-restored.jar", "artifacts/libraries.jar", "runtime/java/bin/javaw.exe", "runtime/natives/lwjgl64.dll", "runtime/assets/indexes/1.8.json", "package.manifest" }.All(path => File.Exists(Path.Combine(root, path)));
    }
    static void VerifyFiles(string root) {
        string prefix = Path.GetFullPath(root) + Path.DirectorySeparatorChar;
        foreach (string line in File.ReadLines(Path.Combine(root, "package.manifest"), Encoding.UTF8)) {
            string[] values = line.Split('\t');
            if (values.Length != 3) throw new IOException("Invalid package manifest.");
            string path = Path.GetFullPath(Path.Combine(root, values[0].Replace('/', Path.DirectorySeparatorChar)));
            if (!path.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) throw new IOException("Invalid manifest path.");
            if (!File.Exists(path) || new FileInfo(path).Length != long.Parse(values[1])) throw new IOException("Missing or incomplete file: " + values[0]);
            using (var input = File.OpenRead(path))
            using (var algorithm = SHA256.Create()) {
                if (Hex(algorithm.ComputeHash(input)) != values[2]) throw new IOException("File checksum mismatch: " + values[0]);
            }
        }
    }
    static string Quote(string value) {
        var result = new StringBuilder("\"");
        int slashes = 0;
        foreach (char character in value) {
            if (character == '\\') { slashes++; continue; }
            if (character == '"') result.Append('\\', slashes * 2 + 1);
            else result.Append('\\', slashes);
            result.Append(character); slashes = 0;
        }
        return result.Append('\\', slashes * 2).Append('"').ToString();
    }
    static string Arguments(IEnumerable<string> values) { return string.Join(" ", values.Select(Quote).ToArray()); }
    static void Launch(string root, bool launchOnly) {
        var values = new List<string> { "-Drise.launcher.data=" + dataDirectory, "-jar", Path.Combine(root, "RiseLocalLauncher.jar") };
        if (launchOnly) values.Add("--launch-only");
        var info = new ProcessStartInfo(Path.Combine(root, "runtime/java/bin/javaw.exe"), Arguments(values));
        info.WorkingDirectory = root; info.UseShellExecute = false; info.CreateNoWindow = true;
        using (var process = Process.Start(info)) {
            File.WriteAllText(Path.Combine(dataDirectory, "launcher.pid"), process.Id.ToString());
            File.WriteAllText(Path.Combine(dataDirectory, "runtime.path"), root, Encoding.UTF8);
        }
    }
    static int Verify(string root) {
        using (var fontCheck = new PreparationWindow()) { }
        string classpath = string.Join(";", new[] { "launcher/offline-patches.jar", "artifacts/client-restored.jar", "RiseLocalLauncher.jar", "artifacts/libraries.jar" }.Select(path => Path.Combine(root, path)).ToArray());
        string natives = Path.Combine(root, "runtime/natives");
        var info = new ProcessStartInfo(Path.Combine(root, "runtime/java/bin/java.exe"), Arguments(new[] { "--enable-native-access=ALL-UNNAMED", "-Djava.library.path=" + natives, "-Drise.native.directory=" + natives, "-cp", classpath, "VerifyOfflineRuntime" }));
        info.WorkingDirectory = root; info.UseShellExecute = false; info.CreateNoWindow = true; info.RedirectStandardOutput = true; info.RedirectStandardError = true;
        info.EnvironmentVariables["PATH"] = natives + ";" + Path.Combine(root, "runtime/java/bin") + ";" + (info.EnvironmentVariables["PATH"] ?? "");
        using (var process = Process.Start(info)) {
            string output = process.StandardOutput.ReadToEnd() + process.StandardError.ReadToEnd();
            process.WaitForExit();
            File.WriteAllText(Path.Combine(dataDirectory, "verification.log"), output, Encoding.UTF8);
            File.WriteAllText(Path.Combine(dataDirectory, "runtime.path"), root, Encoding.UTF8);
            return process.ExitCode;
        }
    }

    sealed class PackageStream : Stream {
        readonly Stream source;
        readonly long start, size;
        long position;
        public PackageStream(Stream input, long offset, long length) { source = input; start = offset; size = length; }
        public override bool CanRead { get { return true; } }
        public override bool CanSeek { get { return true; } }
        public override bool CanWrite { get { return false; } }
        public override long Length { get { return size; } }
        public override long Position { get { return position; } set { Seek(value, SeekOrigin.Begin); } }
        public override int Read(byte[] buffer, int offset, int count) {
            count = (int)Math.Min(count, size - position);
            source.Position = start + position;
            int read = source.Read(buffer, offset, count); position += read; return read;
        }
        public override long Seek(long offset, SeekOrigin origin) {
            long next = origin == SeekOrigin.Begin ? offset : origin == SeekOrigin.Current ? position + offset : size + offset;
            if (next < 0 || next > size) throw new IOException("Invalid package stream position.");
            return position = next;
        }
        public override void Flush() { }
        public override void SetLength(long value) { throw new NotSupportedException(); }
        public override void Write(byte[] buffer, int offset, int count) { throw new NotSupportedException(); }
    }

    sealed class PreparationWindow : Form {
        readonly ProgressTrack bar = new ProgressTrack();
        readonly Label detail = new Label();
        readonly PrivateFontCollection fonts = new PrivateFontCollection();
        IntPtr fontData;
        public PreparationWindow() {
            using (var input = Assembly.GetExecutingAssembly().GetManifestResourceStream("Inter.ttf")) {
                byte[] bytes = new byte[input.Length]; input.Read(bytes, 0, bytes.Length);
                fontData = Marshal.AllocHGlobal(bytes.Length); Marshal.Copy(bytes, 0, fontData, bytes.Length); fonts.AddMemoryFont(fontData, bytes.Length);
            }
            Font = new Font(fonts.Families[0], 11f);
            Text = "Rise Launcher"; ClientSize = new Size(480, 180); StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog; ControlBox = false;
            BackColor = Color.FromArgb(16, 18, 20); ForeColor = Color.FromArgb(235, 238, 240);
            var title = new Label { Text = "Rise", AutoSize = true, Location = new Point(26, 20), Font = new Font(fonts.Families[0], 28f, FontStyle.Bold) };
            detail.Text = "Checking files..."; detail.ForeColor = Color.FromArgb(143, 152, 160); detail.SetBounds(28, 84, 428, 25);
            bar.SetBounds(28, 132, 424, 3);
            string preferences = Path.Combine(dataDirectory, "launcher.properties");
            bar.Animated = !File.Exists(preferences) || !File.ReadLines(preferences).Any(line => line.Trim().Equals("animations=false", StringComparison.OrdinalIgnoreCase));
            Controls.Add(title); Controls.Add(detail); Controls.Add(bar);
        }
        public void UpdateProgress(int value, string text) {
            if (IsDisposed) return;
            BeginInvoke(new Action(delegate { bar.Value = Math.Max(0, Math.Min(100, value)); detail.Text = text; }));
        }
        protected override void Dispose(bool disposing) {
            base.Dispose(disposing);
            if (disposing) { fonts.Dispose(); if (fontData != IntPtr.Zero) { Marshal.FreeHGlobal(fontData); fontData = IntPtr.Zero; } }
        }
    }
    sealed class ProgressTrack : Control {
        int value;
        double shown;
        long previous;
        public bool Animated = true;
        readonly System.Windows.Forms.Timer animation = new System.Windows.Forms.Timer { Interval = 16 };
        public int Value { get { return value; } set { this.value = value; if (Animated && Visible) { previous = Stopwatch.GetTimestamp(); animation.Start(); } else shown = value; Invalidate(); } }
        public ProgressTrack() {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
            animation.Tick += delegate {
                long now = Stopwatch.GetTimestamp();
                double elapsed = previous == 0 ? .016 : Math.Min(.05, (double)(now - previous) / Stopwatch.Frequency); previous = now;
                shown += (value - shown) * (1 - Math.Exp(-elapsed / .085));
                if (value > 0 && Math.Abs(value - shown) < .05) { shown = value; animation.Stop(); }
                Invalidate();
            };
        }
        protected override void OnPaint(PaintEventArgs e) {
            e.Graphics.Clear(Color.FromArgb(44, 49, 54));
            using (var brush = new SolidBrush(Color.FromArgb(151, 193, 248))) {
                if (value <= 0) {
                    double phase = Animated ? (double)Stopwatch.GetTimestamp() / Stopwatch.Frequency / 1.2 % 1 : .4;
                    int width = Width / 5; e.Graphics.FillRectangle(brush, (int)((Width + width) * phase) - width, 0, width, Height);
                } else e.Graphics.FillRectangle(brush, 0, 0, (float)(Width * shown / 100), Height);
            }
        }
        protected override void OnVisibleChanged(EventArgs e) { base.OnVisibleChanged(e); if (animation == null) return; if (Visible && Animated && (value == 0 || Math.Abs(shown - value) > .05)) { previous = Stopwatch.GetTimestamp(); animation.Start(); } else animation.Stop(); }
        protected override void OnHandleDestroyed(EventArgs e) { animation.Stop(); base.OnHandleDestroyed(e); }
        protected override void Dispose(bool disposing) { if (disposing) animation.Dispose(); base.Dispose(disposing); }
    }
}
