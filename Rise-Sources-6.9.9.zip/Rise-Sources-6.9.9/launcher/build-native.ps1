$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path -Parent $PSScriptRoot
$nativeBuild = Join-Path $taskRoot 'work/native-build'
New-Item -ItemType Directory -Force -Path $nativeBuild,(Join-Path $taskRoot 'runtime/natives') | Out-Null
$vsWhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio/Installer/vswhere.exe'
if (-not (Test-Path -LiteralPath $vsWhere)) { throw 'Visual Studio C++ tools were not found.' }
$vsDirectory = & $vsWhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if (-not $vsDirectory) { throw 'Visual Studio C++ tools were not found.' }
$vcVars = Join-Path $vsDirectory 'VC/Auxiliary/Build/vcvars64.bat'
$javaProperties = & java -XshowSettings:properties -version 2>&1
$jniRuntimeHome = ($javaProperties | ForEach-Object { $_.ToString() } | Where-Object { $_ -match '^\s*java\.home\s*=' } | Select-Object -First 1) -replace '^\s*java\.home\s*=\s*',''
if (-not (Test-Path -LiteralPath (Join-Path $jniRuntimeHome 'include/jni.h'))) { throw 'JDK JNI headers were not found.' }
$nativeSource = Join-Path $PSScriptRoot 'native/RawMouseInput.cpp'
$testSource = Join-Path $PSScriptRoot 'native/RawMotionTest.cpp'
$nativeDll = Join-Path $nativeBuild 'rise_raw_input.dll'
$testExecutable = Join-Path $nativeBuild 'RawMotionTest.exe'
$batchPath = Join-Path $nativeBuild 'compile.cmd'
$commands = @"
@echo off
call "$vcVars" >nul
if errorlevel 1 exit /b %errorlevel%
cl /nologo /O2 /MT /LD /EHsc /W4 /std:c++17 /I"$jniRuntimeHome\include" /I"$jniRuntimeHome\include\win32" /Fo"$nativeBuild\RawMouseInput.obj" /Fe"$nativeDll" "$nativeSource" /link /INCREMENTAL:NO /IMPLIB:"$nativeBuild\rise_raw_input.lib" user32.lib
if errorlevel 1 exit /b %errorlevel%
cl /nologo /O2 /MT /EHsc /W4 /std:c++17 /Fo"$nativeBuild\RawMotionTest.obj" /Fe"$testExecutable" "$testSource"
if errorlevel 1 exit /b %errorlevel%
"$testExecutable"
exit /b %errorlevel%
"@
Set-Content -LiteralPath $batchPath -Value $commands -Encoding ASCII
& $env:ComSpec /d /c $batchPath
if ($LASTEXITCODE -ne 0) { throw 'Raw mouse native build or tests failed.' }
Copy-Item -LiteralPath $nativeDll -Destination (Join-Path $taskRoot 'runtime/natives/rise_raw_input.dll')
