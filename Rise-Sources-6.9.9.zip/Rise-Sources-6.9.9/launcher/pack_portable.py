import argparse
import hashlib
import json
import pathlib
import shutil
import struct
import urllib.request
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
MAGIC = b"RISE-PACKAGE-1\0\0"


def digest(path, algorithm="sha256"):
    result = hashlib.new(algorithm)
    with path.open("rb") as source:
        while block := source.read(1024 * 1024):
            result.update(block)
    return result.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--assets", required=True, type=pathlib.Path)
    parser.add_argument("--runtime", required=True, type=pathlib.Path)
    parser.add_argument("--launcher", required=True, type=pathlib.Path)
    parser.add_argument("--stub", required=True, type=pathlib.Path)
    parser.add_argument("--output", required=True, type=pathlib.Path)
    args = parser.parse_args()
    files = {}

    def add(path, name):
        if not path.is_file():
            raise FileNotFoundError(path)
        if name in files:
            raise ValueError("Duplicate package path: " + name)
        files[name] = path

    add(args.launcher / "RiseLocalLauncher.jar", "RiseLocalLauncher.jar")
    add(args.launcher / "launcher/offline-patches.jar", "launcher/offline-patches.jar")
    for name in ("client-restored.jar", "libraries.jar"):
        add(ROOT / "artifacts" / name, "artifacts/" + name)
    for folder, prefix in ((args.runtime, "runtime/java/"), (ROOT / "runtime/natives", "runtime/natives/")):
        for path in sorted(folder.rglob("*")):
            if path.is_file():
                add(path, prefix + path.relative_to(folder).as_posix())
    index_path = args.assets / "indexes/1.8.json"
    add(index_path, "runtime/assets/indexes/1.8.json")
    index = json.loads(index_path.read_text(encoding="utf-8"))
    objects = {}
    for obj in index["objects"].values():
        objects[obj["hash"]] = obj["size"]
    for sha1, size in sorted(objects.items()):
        relative = "objects/" + sha1[:2] + "/" + sha1
        path = args.assets / relative
        if not path.is_file() or path.stat().st_size != size or digest(path, "sha1") != sha1:
            path = ROOT / "work/portable-assets" / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            urllib.request.urlretrieve("https://resources.download.minecraft.net/" + sha1[:2] + "/" + sha1, path)
        if path.stat().st_size != size or digest(path, "sha1") != sha1:
            raise ValueError("Asset checksum mismatch: " + sha1)
        add(path, "runtime/assets/" + relative)
    add(ROOT / "launcher/PORTABLE.txt", "PORTABLE.txt")
    add(ROOT / "launcher/temurin.json", "runtime/java-download.json")
    manifest = "".join(name + "\t" + str(path.stat().st_size) + "\t" + digest(path) + "\n" for name, path in sorted(files.items()))
    payload = ROOT / "work/portable-payload.zip"
    with zipfile.ZipFile(payload, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
        for name, path in sorted(files.items()):
            archive.write(path, name)
        archive.writestr("package.manifest", manifest.encode("utf-8"))
    package_hash = digest(payload)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.output.with_suffix(".building")
    with temporary.open("wb") as output:
        for path in (args.stub, payload):
            with path.open("rb") as source:
                shutil.copyfileobj(source, output, 1024 * 1024)
        output.write(struct.pack("<16sQ32sQ", MAGIC, payload.stat().st_size, bytes.fromhex(package_hash), len(files) + 1))
    temporary.replace(args.output)
    report = {
        "executable": str(args.output.resolve()),
        "bytes": args.output.stat().st_size,
        "sha256": digest(args.output),
        "payload_sha256": package_hash,
        "files": len(files) + 1,
        "asset_objects": len(objects),
        "asset_bytes": sum(objects.values()),
        "unpacked_bytes": sum(path.stat().st_size for path in files.values()),
        "platform": "Windows x64",
    }
    (ROOT / "reference/portable-build.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2), flush=True)


if __name__ == "__main__":
    main()
