#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <jni.h>
#include <vector>
#include "RawMotion.h"

static SRWLOCK motionLock = SRWLOCK_INIT;
static RawMotion motion;
static HANDLE worker = nullptr, ready = nullptr;
static HWND receiver = nullptr;
static DWORD workerId = 0;
static volatile LONG running = 0, lastError = 0;
static const wchar_t* windowClass = L"RiseRawMouseInput";

static bool foreground() {
    DWORD process = 0;
    HWND window = GetForegroundWindow();
    if (window) GetWindowThreadProcessId(window, &process);
    return process == GetCurrentProcessId();
}
static void processInput(const RAWINPUT* input) {
    if (input->header.dwType != RIM_TYPEMOUSE) return;
    const RAWMOUSE& mouse = input->data.mouse;
    AcquireSRWLockExclusive(&motionLock);
    if (foreground()) motion.add(mouse.lLastX, mouse.lLastY, (mouse.usFlags & MOUSE_MOVE_ABSOLUTE) != 0);
    else motion.clear();
    ReleaseSRWLockExclusive(&motionLock);
}
static void drainQueue() {
    alignas(8) BYTE buffer[65536];
    for (;;) {
        UINT size = sizeof(buffer);
        UINT count = GetRawInputBuffer(reinterpret_cast<RAWINPUT*>(buffer), &size, sizeof(RAWINPUTHEADER));
        if (count == 0 || count == static_cast<UINT>(-1)) return;
        RAWINPUT* input = reinterpret_cast<RAWINPUT*>(buffer);
        for (UINT i = 0; i < count; ++i) {
            processInput(input);
            std::uintptr_t next = reinterpret_cast<std::uintptr_t>(input) + input->header.dwSize;
            next = (next + sizeof(void*) - 1) & ~(sizeof(void*) - 1);
            input = reinterpret_cast<RAWINPUT*>(next);
        }
    }
}
static LRESULT CALLBACK windowProc(HWND window, UINT message, WPARAM wParam, LPARAM lParam) {
    if (message == WM_INPUT) {
        RAWINPUT input{};
        UINT size = sizeof(input);
        UINT bytes = GetRawInputData(reinterpret_cast<HRAWINPUT>(lParam), RID_INPUT, &input, &size, sizeof(RAWINPUTHEADER));
        if (bytes != static_cast<UINT>(-1) && bytes >= sizeof(RAWINPUTHEADER) + sizeof(RAWMOUSE)) processInput(&input);
        drainQueue();
        return DefWindowProcW(window, message, wParam, lParam);
    }
    if (message == WM_TIMER) {
        if (!foreground()) { AcquireSRWLockExclusive(&motionLock); motion.clear(); ReleaseSRWLockExclusive(&motionLock); }
        return 0;
    }
    if (message == WM_CLOSE) { DestroyWindow(window); return 0; }
    if (message == WM_DESTROY) { PostQuitMessage(0); return 0; }
    return DefWindowProcW(window, message, wParam, lParam);
}
static bool mouseAlreadyRegistered() {
    UINT count = 0;
    if (GetRegisteredRawInputDevices(nullptr, &count, sizeof(RAWINPUTDEVICE)) == static_cast<UINT>(-1)) return true;
    std::vector<RAWINPUTDEVICE> devices(count);
    if (count && GetRegisteredRawInputDevices(devices.data(), &count, sizeof(RAWINPUTDEVICE)) == static_cast<UINT>(-1)) return true;
    for (const auto& device : devices) if (device.usUsagePage == 1 && device.usUsage == 2) return true;
    return false;
}
static DWORD WINAPI inputThread(void*) {
    HINSTANCE instance = GetModuleHandleW(nullptr);
    WNDCLASSW type{}; type.lpfnWndProc = windowProc; type.hInstance = instance; type.lpszClassName = windowClass;
    if (!RegisterClassW(&type)) { InterlockedExchange(&lastError, static_cast<LONG>(GetLastError())); SetEvent(ready); return 1; }
    HWND window = CreateWindowExW(0, windowClass, L"", 0, 0, 0, 0, 0, HWND_MESSAGE, nullptr, instance, nullptr);
    if (!window) { InterlockedExchange(&lastError, static_cast<LONG>(GetLastError())); SetEvent(ready); UnregisterClassW(windowClass, instance); return 1; }
    receiver = window;
    if (mouseAlreadyRegistered()) {
        InterlockedExchange(&lastError, ERROR_ALREADY_EXISTS); SetEvent(ready); DestroyWindow(window); receiver = nullptr; UnregisterClassW(windowClass, instance); return 1;
    }
    RAWINPUTDEVICE device{ 1, 2, RIDEV_INPUTSINK, window };
    if (!RegisterRawInputDevices(&device, 1, sizeof(device))) {
        InterlockedExchange(&lastError, static_cast<LONG>(GetLastError())); SetEvent(ready); DestroyWindow(window); receiver = nullptr; UnregisterClassW(windowClass, instance); return 1;
    }
    SetTimer(window, 1, 8, nullptr); InterlockedExchange(&running, 1); SetEvent(ready);
    MSG message{};
    while (GetMessageW(&message, nullptr, 0, 0) > 0) { TranslateMessage(&message); DispatchMessageW(&message); }
    KillTimer(window, 1);
    RAWINPUTDEVICE remove{ 1, 2, RIDEV_REMOVE, nullptr }; RegisterRawInputDevices(&remove, 1, sizeof(remove));
    if (IsWindow(window)) DestroyWindow(window);
    receiver = nullptr; InterlockedExchange(&running, 0); UnregisterClassW(windowClass, instance);
    return 0;
}
extern "C" JNIEXPORT jint JNICALL Java_rise_local_input_RawMouseInput_nStart(JNIEnv*, jclass) {
    if (worker) return running ? 0 : lastError;
    InterlockedExchange(&lastError, 0);
    ready = CreateEventW(nullptr, TRUE, FALSE, nullptr);
    if (!ready) return static_cast<jint>(GetLastError());
    worker = CreateThread(nullptr, 0, inputThread, nullptr, 0, &workerId);
    if (!worker) { DWORD error = GetLastError(); CloseHandle(ready); ready = nullptr; return static_cast<jint>(error); }
    if (WaitForSingleObject(ready, 3000) != WAIT_OBJECT_0) return ERROR_TIMEOUT;
    return running ? 0 : lastError;
}
extern "C" JNIEXPORT void JNICALL Java_rise_local_input_RawMouseInput_nCapture(JNIEnv*, jclass, jboolean capture) {
    AcquireSRWLockExclusive(&motionLock); motion.capture(capture == JNI_TRUE); ReleaseSRWLockExclusive(&motionLock);
}
extern "C" JNIEXPORT jlong JNICALL Java_rise_local_input_RawMouseInput_nPoll(JNIEnv*, jclass) {
    std::int32_t x = 0, y = 0;
    AcquireSRWLockExclusive(&motionLock);
    if (!foreground()) motion.clear();
    bool usable = motion.poll(x, y);
    ReleaseSRWLockExclusive(&motionLock);
    if (!usable) return static_cast<jlong>(0x8000000080000000ULL);
    return static_cast<jlong>((static_cast<std::uint64_t>(static_cast<std::uint32_t>(x)) << 32) | static_cast<std::uint32_t>(y));
}
extern "C" JNIEXPORT jboolean JNICALL Java_rise_local_input_RawMouseInput_nRegistered(JNIEnv*, jclass) {
    UINT count = 0; GetRegisteredRawInputDevices(nullptr, &count, sizeof(RAWINPUTDEVICE));
    std::vector<RAWINPUTDEVICE> devices(count);
    if (!count || GetRegisteredRawInputDevices(devices.data(), &count, sizeof(RAWINPUTDEVICE)) == static_cast<UINT>(-1)) return JNI_FALSE;
    for (const auto& device : devices) if (device.usUsagePage == 1 && device.usUsage == 2 && device.hwndTarget == receiver && !(device.dwFlags & RIDEV_NOLEGACY)) return JNI_TRUE;
    return JNI_FALSE;
}
extern "C" JNIEXPORT void JNICALL Java_rise_local_input_RawMouseInput_nStop(JNIEnv*, jclass) {
    AcquireSRWLockExclusive(&motionLock); motion.capture(false); ReleaseSRWLockExclusive(&motionLock);
    if (!worker) return;
    if (receiver) PostMessageW(receiver, WM_CLOSE, 0, 0); else PostThreadMessageW(workerId, WM_QUIT, 0, 0);
    if (WaitForSingleObject(worker, 3000) == WAIT_OBJECT_0) {
        CloseHandle(worker); worker = nullptr;
        if (ready) { CloseHandle(ready); ready = nullptr; }
    }
}
