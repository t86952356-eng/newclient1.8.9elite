#pragma once
#include <cstdint>
#include <climits>

struct RawMotion {
    bool capturing = false;
    bool absolute = false;
    std::int64_t x = 0, y = 0;

    void clear() { x = y = 0; absolute = false; }
    void capture(bool value) { if (value != capturing || !value) clear(); capturing = value; }
    void add(std::int32_t dx, std::int32_t dy, bool isAbsolute) {
        if (!capturing) return;
        if (isAbsolute) { absolute = true; return; }
        x += dx; y += dy;
    }
    static std::int32_t clamp(std::int64_t value) {
        return value > INT_MAX ? INT_MAX : value < INT_MIN ? INT_MIN : static_cast<std::int32_t>(value);
    }
    bool poll(std::int32_t& dx, std::int32_t& dy) {
        bool usable = capturing && !absolute;
        dx = usable ? clamp(x) : 0; dy = usable ? clamp(-y) : 0;
        clear(); return usable;
    }
};
