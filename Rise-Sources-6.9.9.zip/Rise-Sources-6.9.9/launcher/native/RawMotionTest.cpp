#include "RawMotion.h"
#include <cassert>
#include <iostream>

int main() {
    RawMotion motion; std::int32_t x, y;
    motion.add(100, 100, false); assert(!motion.poll(x, y) && x == 0 && y == 0);
    motion.capture(true); motion.add(17, -9, false); motion.add(-5, 3, false);
    assert(motion.poll(x, y) && x == 12 && y == 6);
    assert(motion.poll(x, y) && x == 0 && y == 0);
    motion.add(7, 8, false); motion.capture(false); motion.capture(true);
    assert(motion.poll(x, y) && x == 0 && y == 0);
    motion.add(65535, 32000, true); assert(!motion.poll(x, y));
    for(int i=0;i<8000;i++)motion.add(3,-2,false);
    assert(motion.poll(x, y) && x == 24000 && y == 16000);
    motion.add(INT_MAX, INT_MIN, false); motion.add(INT_MAX, INT_MIN, false);
    assert(motion.poll(x, y) && x == INT_MAX && y == INT_MAX);
    std::cout << "Raw motion signs, accumulation, focus reset, absolute fallback, 8,000 events and saturation passed.\n";
}
