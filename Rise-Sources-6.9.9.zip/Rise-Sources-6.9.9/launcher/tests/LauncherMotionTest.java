package rise.local.ui;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.concurrent.atomic.AtomicInteger;
import javax.swing.*;

public final class LauncherMotionTest {
    private static Motion.Tween tween;
    private static JButton button;
    private static JCheckBox toggle;
    private static int normal, hovered;
    private static final AtomicInteger completed = new AtomicInteger();
    private static int pixel(JComponent component) {
        BufferedImage image = new BufferedImage(160, 44, BufferedImage.TYPE_INT_ARGB);
        Graphics2D graphics = image.createGraphics(); component.paint(graphics); graphics.dispose(); return image.getRGB(10, 10);
    }
    private static void check(boolean value, String message) { if (!value) throw new AssertionError(message); }
    public static void main(String[] args) throws Exception {
        SwingUtilities.invokeAndWait(() -> {
            try { LauncherTheme.install(); } catch (Exception error) { throw new RuntimeException(error); }
            Motion.setEnabled(true); tween = new Motion.Tween(0, value -> {});
            tween.to(1, 220, 0, completed::incrementAndGet);
        });
        Thread.sleep(70);
        SwingUtilities.invokeAndWait(() -> {
            double before = tween.value(); check(before > .05 && before < .99, "Transition jumped to its endpoint");
            tween.to(0, 180, 0, completed::incrementAndGet);
            check(Math.abs(tween.value() - before) < .06, "Interrupted transition jumped");
        });
        Thread.sleep(260);
        SwingUtilities.invokeAndWait(() -> {
            check(tween.value() == 0, "Transition did not reach its target");
            check(completed.get() == 1, "An interrupted completion callback ran");
            check(Motion.activeCount() == 0, "The frame clock kept running while idle");
            button = LauncherTheme.button("Launch Rise", true); button.setSize(160, 44); normal = pixel(button);
            button.getModel().setRollover(true);
            check(pixel(button) == normal, "Hover color changed instantly");
            toggle = new JCheckBox("Raw input"); LauncherTheme.toggle(toggle); toggle.setSelected(true);
            check(toggle.isSelected(), "Toggle input waited for its animation");
        });
        Thread.sleep(45);
        final int[] middle = new int[1];
        SwingUtilities.invokeAndWait(() -> { middle[0] = pixel(button); check(middle[0] != normal, "Hover had no intermediate frame"); });
        Thread.sleep(240);
        SwingUtilities.invokeAndWait(() -> {
            hovered = pixel(button); check(hovered != middle[0], "Hover did not continue smoothly");
            check(Motion.activeCount() == 0, "Completed control animations did not stop");
            Motion.setEnabled(false); tween.to(1, 1000, 0, completed::incrementAndGet);
            check(tween.value() == 1 && Motion.activeCount() == 0, "Reduced motion did not finish immediately");
            button.getModel().setRollover(false);
            check(pixel(button) == normal, "Reduced motion still animated the button");
            Motion.setEnabled(true);
        });
        System.out.println("Animation interruption, intermediate frames, immediate input, reduced motion and idle clock passed.");
    }
}
