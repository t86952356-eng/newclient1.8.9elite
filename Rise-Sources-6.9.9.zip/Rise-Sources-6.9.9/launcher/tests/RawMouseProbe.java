import rise.local.input.RawMouseInput;

public final class RawMouseProbe {
    public static void main(String[] args) {
        boolean expected=Boolean.parseBoolean(System.getProperty("rise.rawMouse","true"));
        if(RawMouseInput.isAvailable()!=expected)throw new AssertionError("Raw input availability did not match the setting");
        if(expected&&!RawMouseInput.isRegistered())throw new AssertionError("Raw input receiver was not registered or removed legacy mouse events");
        if(RawMouseInput.isCapturing())throw new AssertionError("Raw input captured the desktop before entering the game");
        RawMouseInput.shutdown();if(RawMouseInput.isRegistered())throw new AssertionError("Raw input receiver did not shut down");
        System.out.println("Raw input setting, Windows receiver, legacy events and shutdown passed.");
    }
}
