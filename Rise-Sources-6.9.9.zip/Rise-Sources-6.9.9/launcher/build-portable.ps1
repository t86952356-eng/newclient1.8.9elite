param([string]$AssetsDirectory)
$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path -Parent $PSScriptRoot
if (-not $AssetsDirectory) { $AssetsDirectory = Join-Path $env:APPDATA '.minecraft/assets' }
Push-Location $taskRoot
try {
    $outputRoot = Join-Path $taskRoot 'work/portable-build'
    $configRepository = Join-Path $taskRoot 'work/RiseOnlineConfigs'
    if (-not (Test-Path -LiteralPath (Join-Path $configRepository '.git'))) {
        & git clone --depth 1 https://github.com/risellc/RiseOnlineConfigs.git $configRepository
        if ($LASTEXITCODE -ne 0) { throw 'CAS repository download failed.' }
    }
    else {
        & git -C $configRepository fetch --depth 1 origin main
        if ($LASTEXITCODE -ne 0) { throw 'CAS repository update failed.' }
        & git -C $configRepository checkout --detach FETCH_HEAD
        if ($LASTEXITCODE -ne 0) { throw 'CAS repository snapshot failed.' }
    }
    & python launcher/snapshot_configs.py
    if ($LASTEXITCODE -ne 0) { throw 'CAS snapshot creation failed.' }
    & (Join-Path $PSScriptRoot 'build.ps1') -OutputDirectory $outputRoot
    if (-not (Test-Path -LiteralPath 'launcher/temurin.json')) {
        $metadata = Invoke-RestMethod -Uri 'https://api.adoptium.net/v3/assets/latest/21/hotspot?architecture=x64&image_type=jre&os=windows&vendor=eclipse'
        $metadata[0] | ConvertTo-Json -Depth 12 | Set-Content -Encoding UTF8 -LiteralPath 'launcher/temurin.json'
    }
    $runtimeMetadata = Get-Content -Raw -LiteralPath 'launcher/temurin.json' | ConvertFrom-Json
    $archivePath = Join-Path $taskRoot 'tools/temurin21-jre-windows.zip'
    if (-not (Test-Path -LiteralPath $archivePath)) { Invoke-WebRequest -Uri $runtimeMetadata.binary.package.link -OutFile $archivePath }
    if ((Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash -ne $runtimeMetadata.binary.package.checksum) { throw 'Java archive checksum mismatch.' }
    $runtimeFolder = Join-Path $taskRoot 'work/temurin21'
    Expand-Archive -LiteralPath $archivePath -DestinationPath $runtimeFolder -Force
    $runtimeHome = Get-ChildItem -LiteralPath $runtimeFolder -Directory | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'bin/javaw.exe') } | Select-Object -First 1
    if (-not $runtimeHome) { throw 'Bundled Java runtime was not found.' }
    $compiler = Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
    $compilerArguments = @('/nologo','/target:winexe','/platform:x64','/optimize+',('/out:' + (Join-Path $taskRoot 'launcher\build\PortableStub.exe')),('/resource:' + (Join-Path $taskRoot 'Inter_18pt-Regular.ttf') + ',Inter.ttf'),'/reference:System.Drawing.dll','/reference:System.Windows.Forms.dll','/reference:System.IO.Compression.dll','/reference:System.IO.Compression.FileSystem.dll',(Join-Path $taskRoot 'launcher\src\PortableLauncher.cs'))
    & $compiler @compilerArguments
    if ($LASTEXITCODE -ne 0) { throw 'Portable bootstrap compilation failed.' }
    & python launcher/pack_portable.py --assets $AssetsDirectory --runtime $runtimeHome.FullName --launcher $outputRoot --stub launcher/build/PortableStub.exe --output dist/RiseLauncher.exe
    if ($LASTEXITCODE -ne 0) { throw 'Portable package creation failed.' }
}
finally { Pop-Location }
